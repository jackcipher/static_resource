<?php

namespace App\Api\V1\Controllers;

use Illuminate\Routing\Controller as BaseController;
use Dingo\Api\Routing\Helpers;

class Controller extends BaseController {
    use Helpers;
}